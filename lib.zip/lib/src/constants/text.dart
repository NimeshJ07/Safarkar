const String tOnBoardTitle1 = "Welcome to safar_kar";
const String tOnBoardTitle2 = "Book your Tickets";
const String tOnBoardTitle3 = "Unique Tickets";

const String tOnBoardSubTitle1 =
    "A Blockchain based online ticket booking system";
const String tOnBoardSubTitle2 =
    "Book your e-ticket without any hurdles and an easy way";
const String tOnBoardSubTitle3 =
    "A tickets unique because it has NFT and Token System";

const String tOnBoardCnt1 = "1/3";
const String tOnBoardCnt2 = "2/3";
const String tOnBoardCnt3 = "3/3";

//welcome

const String tWelTitle = "Revolutionizing Railways Tickets";
const String tWelSubTitle = "Elevating Your Train Journey with Trust and Speed";

//login
const String tLoginTitle = "Welcome Back,";
const String tLoginSubTitle = "Make it right, make it work, make it fast. ";
const String tRme = "Remember Me";
const String tAcc = "Already have an Account ? ";

//Signup

const String tSignUpTilte = "Get On Board,";
const String tSignUpSubTitle = "Create your profile to start your journey";

//forgot

const String tFpTitle = "Make Selection!";
const String tFpSubTitle =
    "Select one of the options given below to reset your password.";
const String temail = "Reset via E-Mail Verification.";
const String tcontact = "Reset via Phone Verification.";
const String tFpConTitle = "Enter your registered Phone no to receive OTP";
const String tFpEmailTitle = "Enter your registered E-Mail to receive OTP";
const String tOtpTitle = "OTP Code Verification";
const String tOtpSubTitle = "Enter the verification code sent at ";
