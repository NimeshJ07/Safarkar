const String tSplashImage = "assets/images/TrainLogo.png";

// onBoarding Screen
const String tOnBoard1 = "assets/images/onboard/onboard1.png";
const String tOnBoard2 = "assets/images/onboard/onboard2.png";
const String tOnBoard3 = "assets/images/onboard/onboard3.png";

//welcome
const String tWelcome = "assets/images/welcome/ticket.png";
const String tBooking = "assets/images/welcome/booking.png";
const String tBookingHistory = "assets/images/welcome/history.png";
const String tPlatformTicket = "assets/images/welcome/train-platform.png";
const String tSeasonalBooking = "assets/images/welcome/reservation.png";
const String tCurrency = "assets/images/welcome/currency.png";
const String tMaps = "assets/images/welcome/map.png";
const String tPenalty = "assets/images/welcome/punishment.png";
const String tRailMap = "assets/images/welcome/RailMap.png";

const String tGoogle = "assets/images/logo/google.png";
const String tLogin = "assets/images/logo/rail.png";
const String tFp = "assets/images/logo/forgot-password.png";
const String tOtp = "assets/images/logo/otp.png";
const String tProfile = "assets/images/logo/user.png";
